import repositorycarrito from '../repositories/carritoRepository.js'
import model from '../models/carrito.js'
const repository = new repositorycarrito(model);

const findAll =   async (req, res) => {
  const carrito =  await repository.findAll();
  return res.status(200).json(carrito);
};

const addItem = async (req, res) => {
  const producto = req.body;
  const carritoActualizado = await repository.addItem(producto);
  return res.status(201).json(carritoActualizado);
};

const remove = async (req, res) => {
  const id = req.params.id;
  const result = await repository.remove(id);
  return res.status(200).json({ success: result, message: result ? 'Producto eliminado' : 'Producto no encontrado' });
};

const removeAll = async (req, res) => {
  const carritoVacio = await repository.removeAll();
  return res.status(200).json({ message: 'Carrito vaciado', carrito: carritoVacio });
};

const newQuantity = async  (req, res) => {
  const id = req.params.id;
  const { cantidad } = req.body;
  const result = await repository.newQuantity(id, cantidad);
  return res.status(200).json({ success: result, message: result ? 'Cantidad actualizada' : 'Producto no encontrado' });
};

export default { findAll, addItem, remove, removeAll, newQuantity };