import model from '../models/orden.js';
import RepositoryBase from '../repositories/base.js'

const repository = new RepositoryBase(model);
const findAll = async (req, res) => {
    const orden =await  repository.findAll();

    return res.status(200).json(orden);
}

const create = async (req, res) => {
    const orden = req.body;
    const ordenCreated =await repository.create(orden);
    return res.status(201).json(ordenCreated)
}

const findOne = async(req,res) => {
    
    const id = req.params.id;

    const result = await repository.findOne(id);

    return res.status(200).json(result);
}

const update = async (req, res) => {
    const orden = req.body;
    const result = await repository.update(orden);

    return res.status(200).json(result)
}

const remove = async (req, res) => {
    const id = req.params.id;

    const result = await repository.remove(id);

    return res.status(200).json(result);
}

const controller = { findAll, create, findOne, update, remove }

export default controller;