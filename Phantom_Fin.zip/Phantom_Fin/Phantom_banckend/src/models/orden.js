import sequelize from "../config/data.js";
import { DataTypes } from "sequelize";
const orden = sequelize.define('orden', {

  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true,
  },
  items: {
    type: DataTypes.JSON, // Almacena el array completo como JSON
    allowNull: false,
  },
  subtotal: {
    type: DataTypes.DOUBLE,
    allowNull: false,
  },
  direccion: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  tarjeta: {
    type: DataTypes.STRING,
    allowNull: false,
  }
});

export default orden;