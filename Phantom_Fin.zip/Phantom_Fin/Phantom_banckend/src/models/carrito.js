import sequelize from "../config/data.js";
import { DataTypes } from "sequelize";
const carrito = sequelize.define('carrito', {

  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true,
  },
  items: {
    type: DataTypes.JSON, // Almacena el array completo como JSON
    allowNull: false,
  },
  subtotal: {
    type: DataTypes.DOUBLE,
    allowNull: false,
  }
});

export default carrito;