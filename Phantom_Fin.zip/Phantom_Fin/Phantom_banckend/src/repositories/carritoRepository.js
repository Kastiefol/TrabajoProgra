import { Op } from 'sequelize';
import carrito from './carrito.js';

class CarritoRepository {
    constructor(model) {
        this.model = model;
    }

    async findAll() {
        try {
            return await this.model.findAll();
        } catch (error) {
            console.error(error);
            return null;
        }
    }

    async addItem(producto) {
        try {
            // Buscar si el producto ya existe en el carrito
            const carritoExistente = await this.model.findOne({ where: { id: producto.id } });
            if (carritoExistente) {
                // Actualizar cantidad
                const items = JSON.parse(carritoExistente.items);
                const index = items.findIndex(item => item.id === producto.id);

                if (index > -1) {
                    items[index].cantidad += 1;
                } else {
                    items.push({ ...producto, cantidad: 1 });
                }

                carritoExistente.items = JSON.stringify(items);
                carritoExistente.subtotal = items.reduce((acc, curr) => acc + (curr.precio * curr.cantidad), 0);
                await carritoExistente.save();

                return carritoExistente;
            } else {
                // Crear un nuevo carrito
                const nuevoCarrito = {
                    items: JSON.stringify([{ ...producto, cantidad: 1 }]),
                    subtotal: producto.precio
                };
                return await this.model.create(nuevoCarrito);
            }
        } catch (error) {
            console.error(error);
            return null;
        }
    }

    async remove(id) {
        try {
            return await this.model.destroy({ where: { id } });
        } catch (error) {
            console.error(error);
            return null;
        }
    }

    async removeAll() {
        try {
            return await this.model.destroy({ where: {} });
        } catch (error) {
            console.error(error);
            return null;
        }
    }

    async updateQuantity(id, cantidad) {
        try {
            const carritoExistente = await this.model.findOne({ where: { id } });
            if (carritoExistente) {
                const items = JSON.parse(carritoExistente.items);
                const index = items.findIndex(item => item.id === id);

                if (index > -1) {
                    items[index].cantidad = cantidad;
                    carritoExistente.items = JSON.stringify(items);
                    carritoExistente.subtotal = items.reduce((acc, curr) => acc + (curr.precio * curr.cantidad), 0);
                    await carritoExistente.save();
                    return carritoExistente;
                }
            }
            return null;
        } catch (error) {
            console.error(error);
            return null;
        }
    }
}

const carritoRepository = new CarritoRepository(carrito);
export default CarritoRepository;