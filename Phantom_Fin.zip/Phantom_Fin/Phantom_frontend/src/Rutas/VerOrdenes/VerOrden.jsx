import { useNavigate } from 'react-router-dom';
import { useEffect, useState } from 'react';
import './VerOrden.css'
const VerOrden = () =>{
    const [mostrarPopup, setMostrarPopup] = useState(false);
    const abrirPopup = () => setMostrarPopup(true);
    const cerrarPopup = () => setMostrarPopup(false);
    const [ordenes, setOrdenes] = useState()
    const cargarOrdenes = async () => {
        await fetch('http://localhost:4001/orden')
            .then(response => response.json())
            .then(data => setOrdenes(data))
    }

    const calcularSubtotal = (precio, cantidad) => {
        return (parseFloat(precio) * parseInt(cantidad)).toFixed(2);
      };

    const alternarPopup = () => {
        if (mostrarPopup) {
          cerrarPopup();
        } else {
          abrirPopup();
        }
      };

    useEffect(() => {
        cargarOrdenes();
    },[])
    return(
        <main className="verOrden">
         <h1>Ordenes</h1>
        <table className='ordentabla' border="1">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Total</th>
                    <th>Direccion</th>
                </tr>
            </thead>
            <tbody>
                {
                    ordenes?.map(orden => (
                        <tr key={orden.id}>
                            <td>{orden.id}</td>
                            <td>{orden.subtotal}</td>
                            <td>{orden.direccion}</td>
                            <td>
                                <button onClick={alternarPopup}>
                                {mostrarPopup ? 'Cerrar Detalle' : 'Ver Detalle'}</button>
                                </td>
                                {mostrarPopup && (<table>
          <thead>
            <tr>
              <th>Artículo</th>
              <th>Nombre</th>
              <th>Precio</th>
              <th>Subtotal</th>
              <th>Cantidad</th>
            </tr>
          </thead>
          <tbody>
            {orden.items?.map((item) => (
              <tr key={item.id}>
                <td>
                  <img src={item.imagen} alt={item.titulo} style={{ width: '50px' }} />
                </td>
                <td>{item.titulo}</td>
                <td>S/{parseFloat(item.precio).toFixed(2)}</td>
                <td>{calcularSubtotal(item.precio,item.cantidad)}</td>
                <td>    
                  <span>{item.cantidad}</span>  
                </td>
              </tr>
            ))}
          </tbody>
        </table>)}
                        </tr>
                    ))
                }
            </tbody>
        </table>   
        </main>
    )
}

export default VerOrden;