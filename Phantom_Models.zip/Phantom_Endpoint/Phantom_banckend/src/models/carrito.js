const carrito = {
    items: [], // Inicializado como un arreglo vacío.
    subtotal: 0, // Inicializa el subtotal.
  };
  
  export default carrito;