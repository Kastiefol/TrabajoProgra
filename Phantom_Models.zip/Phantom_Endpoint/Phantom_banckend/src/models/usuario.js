const usuarios = [

    {
        id: 1,
        nombre: "",
        apellido: "",
        telefono: "",
        fechaNacimiento: "",
        DNI: "",
        correoelectrico: "nose@gmail.com",
        contraseña: "jojo"
      }
    
]

export default usuarios;