const productos = [
    {
        id: 1,
        titulo: "Sony Ult Wear WHULT900N/BZUC - Audífonos Inalámbricos - Negro",
        precio: 799.90,
        descuento:15,
        descontado: 679.90,
        imagen: "https://phantom.pe/media/catalog/product/cache/c58c05327f55128aefac5642661cf3d1/a/u/audifonos_sony_ult_wear_wh_ult900n_negro_1_.jpg"
    },
    {
        id: 2,
        titulo: "EA Sports FC 25 (PS5)",
        precio: 349.90,
        descuento:null,
        descontado: null ,
        imagen: "https://phantom.pe/media/catalog/product/cache/c58c05327f55128aefac5642661cf3d1/f/c/fc25ps52dpftfront_rola_rgb.jpg"
    },
    {
        id: 3,
        titulo: "PlayStation 5 Slim con ranura de disco",
        precio: 2699.90,
        descuento:null,
        descontado: null ,
        imagen: "https://phantom.pe/media/catalog/product/cache/c58c05327f55128aefac5642661cf3d1/c/o/consola_ps5_slim_disco_playstation_5_1_.jpg"
    },
    {
        id: 4,
        titulo: "Logitech G Pro X League of Legends LOL - Audífonos PC",
        precio: 599.90,
        descuento:43,
        descontado: 349.90 ,
        imagen: "https://phantom.pe/media/catalog/product/cache/c58c05327f55128aefac5642661cf3d1/l/o/lol_2.jpg"
    },
    {
        id: 5,
        titulo: "Funko Pop Jurassic Park - Brachiosaurus",
        precio: 99.90,
        descuento:null,
        descontado: null ,
        imagen: "https://phantom.pe/media/catalog/product/cache/c58c05327f55128aefac5642661cf3d1/f/u/funko_pop_super-_jurassic_park_-_brachiosaurus.jpg"
    },


]

export default productos;