import model from '../models/producto.js'

let produtos = [...model];
let counter = produtos.length;

const findAll = () => {
    return produtos;
}

const create = (producto) => {
    producto.id = ++counter;
    produtos.push(producto);
    
    return producto;
}

const findOne = (id) => {
    const result = produtos.find(x => x.id == id);

    return result;
}

const update = (producto) => {
    const index = produtos.findIndex(item => item.id == producto.id);

    if (index > -1) {
        produtos[index] = producto;
        return true;
    }
    else 
        return false   
}

const remove = (id) => {
    const index = produtos.findIndex(item => item.id == id);

    if (index > -1) {
        produtos.splice(index,1);
        return true;
    }
    else   
        return false;
} 



const repository = { findAll, create, findOne, update, remove }

export default repository;