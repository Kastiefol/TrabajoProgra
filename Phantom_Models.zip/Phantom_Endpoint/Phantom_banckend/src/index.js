import express from 'express';
import bodyParser from 'body-parser';
import cors from 'cors';


import productoRouter from './routes/producto.js';
import carritoRoutes from './routes/carrito.js'
import ordenRoutes from './routes/orden.js' 
import usuarioRoutes from './routes/usuario.js'
const app = express();
app.use(bodyParser.json());
app.use(cors());

app.get('/', (req, resp) => {
    return resp.send('Hello World');
})

app.use('/producto', productoRouter);
app.use('/carrito', carritoRoutes)
app.use('/orden', ordenRoutes)
app.use('/usuario', usuarioRoutes)


app.listen(4001,() => {
    console.log('Server is running on port 4001');
})